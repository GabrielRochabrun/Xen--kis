import { useEffect, useState } from 'react';
import { getSelectedTemperaments } from '../lib/temperaments';

const temperamentNames: Record<string, string> = {
  '12tet': '12-TET',
  '19tet': '19-TET',
  '24tet': '24-TET',
  '31tet': '31-TET'
};

export default function SelectedTemperaments() {
  const [selected, setSelected] = useState<string[]>([]);

  useEffect(() => {
    const updateSelected = () => {
      setSelected(getSelectedTemperaments());
    };

    updateSelected();
    window.addEventListener('storage', updateSelected);
    const interval = setInterval(updateSelected, 1000);

    return () => {
      window.removeEventListener('storage', updateSelected);
      clearInterval(interval);
    };
  }, []);

  if (selected.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50">
      {selected.map(id => (
        <div 
          key={id}
          className="bg-zinc-900 border border-red-500 rounded-lg shadow-lg px-3 py-1.5 flex items-center gap-2"
        >
          <span className="w-2 h-2 bg-red-500 rounded-full" />
          <span className="text-white text-sm">{temperamentNames[id]}</span>
        </div>
      ))}
    </div>
  );
}