import { Bell } from 'lucide-react';

interface NotificationProps {
  message: string;
  type?: 'info' | 'success';
  onClose: () => void;
}

export default function Notification({ message, type = 'info', onClose }: NotificationProps) {
  return (
    <div className="fixed bottom-4 right-4 flex items-center gap-3 bg-zinc-900 border border-zinc-800 rounded-lg p-4 shadow-lg animate-slide-up">
      <Bell className={`w-5 h-5 ${type === 'success' ? 'text-red-500' : 'text-zinc-400'}`} />
      <p className="text-white">{message}</p>
      <button 
        onClick={onClose}
        className="text-zinc-400 hover:text-white transition-colors"
      >
        ×
      </button>
    </div>
  );
}