import { useEffect, useState } from 'react';
import { getSelectedWritingStyles } from '../lib/writing-styles';

const styleNames: Record<string, string> = {
  'uncial': 'Uncial',
  'gothic': 'Gothic',
  'copperplate': 'Copperplate',
  'art-nouveau': 'Art Nouveau',
  'modernist': 'Modernist'
};

export default function SelectedStyles() {
  const [selected, setSelected] = useState<string[]>([]);

  useEffect(() => {
    const updateSelected = () => {
      setSelected(getSelectedWritingStyles());
    };

    updateSelected();
    window.addEventListener('storage', updateSelected);
    const interval = setInterval(updateSelected, 1000);

    return () => {
      window.removeEventListener('storage', updateSelected);
      clearInterval(interval);
    };
  }, []);

  if (selected.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-50">
      {selected.map(id => (
        <div 
          key={id}
          className="bg-zinc-900 border border-red-500 rounded-lg shadow-lg px-3 py-1.5 flex items-center gap-2 mb-2"
        >
          <span className="w-2 h-2 bg-red-500 rounded-full" />
          <span className="text-white text-sm">{styleNames[id]}</span>
        </div>
      ))}
    </div>
  );
}