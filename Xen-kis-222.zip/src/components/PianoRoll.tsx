import React, { useState, useEffect, useRef } from "react";
import * as Tone from "tone";
import { GripVertical, Volume2, ZoomIn, ZoomOut, Move } from 'lucide-react';

interface Track {
  id: string;
  name: string;
  synth: Tone.PolySynth | Tone.Sampler;
  color: string;
  isLoading: boolean;
  isReady: boolean;
}

interface Note {
  x: number;
  y: number;
  width: number;
  height: number;
  noteName: string;
  velocity: number;
}

interface PianoRollProps {
  trackOrder: string[];
  availableTracks: Record<string, Track>;
  isPlaying: boolean;
  bpm: number;
  timeSignature: {
    numerator: number;
    denominator: number;
  };
  onRemoveTrack: (trackId: string) => void;
}

const PianoRoll: React.FC<PianoRollProps> = ({
  trackOrder,
  availableTracks,
  isPlaying,
  bpm,
  timeSignature,
  onRemoveTrack
}) => {
  const generateNotes = () => {
    const notes = [];
    for (let octave = 7; octave >= 0; octave--) {
      notes.push(
        `C${octave}`, `C#${octave}`, `D${octave}`, `D#${octave}`, `E${octave}`,
        `F${octave}`, `F#${octave}`, `G${octave}`, `G#${octave}`, `A${octave}`, `A#${octave}`, `B${octave}`
      );
    }
    return notes;
  };

  const notes = generateNotes();
  const [draggedTrack, setDraggedTrack] = useState<string | null>(null);
  const [playheadPosition, setPlayheadPosition] = useState(0);
  const canvasRefs = useRef<{ [key: string]: HTMLCanvasElement | null }>({});
  const animationFrameRef = useRef<number>();
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [isResizing, setIsResizing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartY, setDragStartY] = useState(0);
  const [trackNotes, setTrackNotes] = useState<{ [key: string]: Note[] }>({});
  const [zoomLevel, setZoomLevel] = useState(1);
  const [lastNoteWidth, setLastNoteWidth] = useState(0);
  const [dragMode, setDragMode] = useState<'none' | 'move' | 'resize'>('none');
  const [dragStartPos, setDragStartPos] = useState({ x: 0, y: 0 });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [highlightedCell, setHighlightedCell] = useState<{ x: number, y: number } | null>(null);
  const [isDragEnabled, setIsDragEnabled] = useState(false);

  useEffect(() => {
    trackOrder.forEach(trackId => {
      if (!trackNotes[trackId]) {
        setTrackNotes(prev => ({
          ...prev,
          [trackId]: []
        }));
      }
    });
  }, [trackOrder]);

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    if (e.ctrlKey) {
      e.preventDefault();
      e.stopPropagation();
      
      const delta = e.deltaY;
      const zoomStep = 0.1;
      
      setZoomLevel(prev => {
        const newZoom = prev + (delta > 0 ? -zoomStep : zoomStep);
        return Math.max(0.5, Math.min(4, newZoom));
      });
    }
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(8, prev + 0.5));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(0.5, prev - 0.5));
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>, trackId: string) => {
    const canvas = canvasRefs.current[trackId];
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    const noteHeight = canvas.height / notes.length;
    const beatWidth = canvas.width / (timeSignature.numerator * 4);
    
    const existingNote = trackNotes[trackId]?.find(note => 
      x >= note.x && x <= note.x + note.width &&
      y >= note.y && y <= note.y + noteHeight
    );

    if (existingNote) {
      setSelectedNote(existingNote);
      setDragStartPos({ x, y });
      setDragOffset({ 
        x: x - existingNote.x,
        y: y - existingNote.y
      });

      const isNearRightEdge = x >= existingNote.x + existingNote.width - 10;
      
      if (isNearRightEdge) {
        setDragMode('resize');
        document.body.style.cursor = 'ew-resize';
        setLastNoteWidth(existingNote.width);
      } else {
        setDragMode('move');
        document.body.style.cursor = 'grabbing';
      }
    } else if (e.button === 0) {
      const gridX = Math.floor(x / beatWidth) * beatWidth;
      const gridY = Math.floor(y / noteHeight) * noteHeight;
      const noteIndex = Math.floor(y / noteHeight);
      const noteName = notes[noteIndex];

      if (noteIndex >= 0 && noteIndex < notes.length) {
        const newNote: Note = {
          x: gridX,
          y: gridY,
          width: beatWidth,
          height: noteHeight,
          noteName,
          velocity: 100
        };

        setTrackNotes(prev => ({
          ...prev,
          [trackId]: [...(prev[trackId] || []), newNote]
        }));
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>, trackId: string) => {
    const canvas = canvasRefs.current[trackId];
    if (!canvas || !selectedNote || dragMode === 'none') return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    const noteHeight = canvas.height / notes.length;
    const beatWidth = canvas.width / (timeSignature.numerator * 4);

    if (dragMode === 'resize') {
      document.body.style.cursor = 'ew-resize';
      
      // Calculate new width with doubling behavior
      const minWidth = beatWidth;
      const rawWidth = x - selectedNote.x;
      const gridWidth = Math.ceil(rawWidth / beatWidth) * beatWidth;
      
      // If this is the first resize movement, double the width
      const newWidth = lastNoteWidth === selectedNote.width 
        ? selectedNote.width * 2 
        : Math.max(minWidth, gridWidth);
      
      setLastNoteWidth(selectedNote.width);
      
      setTrackNotes(prev => ({
        ...prev,
        [trackId]: prev[trackId].map(note =>
          note === selectedNote
            ? { ...note, width: newWidth }
            : note
        )
      }));
    } else if (dragMode === 'move') {
      document.body.style.cursor = 'grabbing';
      
      const newX = x - dragOffset.x;
      const newY = y - dragOffset.y;
      
      const gridX = Math.round(newX / beatWidth) * beatWidth;
      const gridY = Math.round(newY / noteHeight) * noteHeight;
      
      const newNoteIndex = Math.floor(gridY / noteHeight);
      
      if (newNoteIndex >= 0 && newNoteIndex < notes.length) {
        const newNoteName = notes[newNoteIndex];
        
        setTrackNotes(prev => ({
          ...prev,
          [trackId]: prev[trackId].map(note =>
            note === selectedNote
              ? { ...note, x: gridX, y: gridY, noteName: newNoteName }
              : note
          )
        }));
      }
    }
  };

  const handleMouseUp = (trackId: string) => {
    setSelectedNote(null);
    setDragMode('none');
    setHighlightedCell(null);
    document.body.style.cursor = 'default';
  };

  const handleMouseLeave = (trackId: string) => {
    if (selectedNote) {
      handleMouseUp(trackId);
    }
  };

  useEffect(() => {
    if (isPlaying) {
      Tone.Transport.bpm.value = bpm;
      Tone.Transport.start();
      
      const startTime = Tone.now();
      const animate = () => {
        const currentTime = Tone.now() - startTime;
        const beatWidth = canvasRefs.current[trackOrder[0]]?.width / (timeSignature.numerator * 4);
        const newPlayheadPosition = currentTime * (bpm / 60) * beatWidth;
        
        if (newPlayheadPosition !== playheadPosition) {
          trackOrder.forEach(trackId => {
            const track = availableTracks[trackId];
            if (track.isLoading) return;

            trackNotes[trackId]?.forEach(note => {
              const noteStartX = note.x;
              const noteEndX = note.x + note.width;
              
              if (playheadPosition < noteStartX && newPlayheadPosition >= noteStartX) {
                const noteDuration = (note.width / beatWidth) * (60 / bpm);
                track.synth.triggerAttackRelease(note.noteName, noteDuration);
              }
            });
          });
        }
        
        setPlayheadPosition(newPlayheadPosition);
        animationFrameRef.current = requestAnimationFrame(animate);
      };
      
      animate();
    } else {
      Tone.Transport.stop();
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      setPlayheadPosition(0);
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, bpm, timeSignature, trackOrder, trackNotes, availableTracks]);

  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number, trackId: string) => {
    ctx.clearRect(0, 0, width, height);
    
    ctx.fillStyle = '#27272a';
    ctx.fillRect(0, 0, width, height);

    const noteHeight = height / notes.length;
    
    notes.forEach((note, index) => {
      const y = index * noteHeight;
      
      if (note.includes('C')) {
        ctx.fillStyle = note.includes('#') ? '#27272a' : '#3f3f46';
        ctx.fillRect(0, y, width, noteHeight);
      }
      
      ctx.strokeStyle = '#52525b';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();

      ctx.fillStyle = '#a1a1aa';
      ctx.font = 'bold 10px monospace';
      ctx.fillText(note, 5, y + noteHeight - 2);
    });

    const totalBeats = timeSignature.numerator * 4;
    const beatWidth = width / totalBeats;
    
    for (let i = 0; i <= totalBeats; i++) {
      const x = i * beatWidth;
      ctx.strokeStyle = i % 4 === 0 ? '#71717a' : '#52525b';
      ctx.lineWidth = i % 4 === 0 ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    if (highlightedCell) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
      ctx.fillRect(highlightedCell.x, highlightedCell.y, beatWidth, noteHeight);
    }

    trackNotes[trackId]?.forEach(note => {
      ctx.fillStyle = availableTracks[trackId].color;
      ctx.fillRect(note.x, note.y, note.width - 1, note.height - 1);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px monospace';
      ctx.fillText(note.noteName, note.x + 4, note.y + noteHeight - 4);

      if (note === selectedNote) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(note.x + note.width - 4, note.y + 2, 2, note.height - 4);
      }
    });

    if (isPlaying) {
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(playheadPosition, 0);
      ctx.lineTo(playheadPosition, height);
      ctx.stroke();
    }
  };

  useEffect(() => {
    trackOrder.forEach(trackId => {
      const canvas = canvasRefs.current[trackId];
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          drawGrid(ctx, canvas.width, canvas.height, trackId);
        }
      }
    });
  }, [trackOrder, timeSignature, trackNotes, playheadPosition, zoomLevel]);

  const handleDragStart = (trackId: string) => {
    setDraggedTrack(trackId);
  };

  const handleDragOver = (e: React.DragEvent, trackId: string) => {
    e.preventDefault();
    if (!draggedTrack || draggedTrack === trackId) return;
  };

  const handleDragEnd = () => {
    setDraggedTrack(null);
  };

  const renderTrackBlock = (trackId: string) => {
    const track = availableTracks[trackId];
    
    return (
      <div
        key={trackId}
        draggable={isDragEnabled}
        onDragStart={() => isDragEnabled && handleDragStart(trackId)}
        onDragOver={(e) => isDragEnabled && handleDragOver(e, trackId)}
        onDragEnd={handleDragEnd}
        className="bg-zinc-900 border border-zinc-800 rounded-lg shadow-lg mb-4 overflow-hidden"
      >
        <div className="flex items-center p-3 bg-zinc-900 border-b border-zinc-800">
          <GripVertical className={`mr-3 ${isDragEnabled ? 'text-red-500 cursor-move' : 'text-zinc-700 cursor-not-allowed'}`} />
          <h3 className="text-red-500 font-semibold flex-1">{track.name}</h3>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsDragEnabled(!isDragEnabled)}
              className={`p-1.5 rounded-lg transition-colors ${
                isDragEnabled ? 'bg-red-500/10 text-red-500' : 'hover:bg-zinc-800 text-zinc-400'
              }`}
              title={isDragEnabled ? 'Disable Track Movement' : 'Enable Track Movement'}
            >
              <Move className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2 mr-4">
              <button
                onClick={handleZoomOut}
                className="p-1.5 hover:bg-zinc-800 rounded-lg transition-colors text-zinc-400"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-zinc-400 text-sm">{Math.round(zoomLevel * 100)}%</span>
              <button
                onClick={handleZoomIn}
                className="p-1.5 hover:bg-zinc-800 rounded-lg transition-colors text-zinc-400"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center">
              <Volume2 className="text-zinc-700 mr-2" size={18} />
              <input
                type="range"
                min="-60"
                max="12"
                className="w-24"
                onChange={(e) => {
                  track.synth.volume.value = parseFloat(e.target.value);
                }}
              />
            </div>
            <button 
              onClick={() => onRemoveTrack(trackId)}
              className="text-zinc-700 hover:text-red-500 transition-colors"
            >
              ×
            </button>
          </div>
        </div>

        <div className="relative overflow-x-auto overflow-y-hidden" style={{ height: '300px' }}>
          <div 
            style={{
              width: timeSignature.numerator * 4 * 100 * zoomLevel,
              height: '300px',
              position: 'relative'
            }}
          >
            <canvas
              ref={el => canvasRefs.current[trackId] = el}
              width={timeSignature.numerator * 4 * 100 * zoomLevel}
              height={notes.length * 20}
              className="bg-zinc-800"
              onMouseDown={(e) => handleMouseDown(e, trackId)}
              onMouseMove={(e) => handleMouseMove(e, trackId)}
              onMouseUp={() => handleMouseUp(trackId)}
              onMouseLeave={() => handleMouseLeave(trackId)}
              onWheel={handleWheel}
              onContextMenu={(e) => e.preventDefault()}
            />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col p-4 bg-gradient-to-br from-red-950 via-zinc-900 to-black min-h-screen">
      <div className="space-y-4">
        {trackOrder.map(trackId => renderTrackBlock(trackId))}
      </div>
      {trackOrder.length === 0 && (
        <div className="text-zinc-600 text-center py-8 bg-zinc-900/50 rounded-lg border border-zinc-800">
          Click "Add Track" to start composing
        </div>
      )}
    </div>
  );
};

export default PianoRoll;