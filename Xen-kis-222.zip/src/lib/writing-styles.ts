// Key for storing selected writing styles in localStorage
const SELECTED_WRITING_STYLES_KEY = 'selectedWritingStyles';

// Get selected writing styles
export function getSelectedWritingStyles(): string[] {
  const stored = localStorage.getItem(SELECTED_WRITING_STYLES_KEY);
  return stored ? JSON.parse(stored) : [];
}

// Save selected writing styles
export function saveSelectedWritingStyles(styles: string[]) {
  localStorage.setItem(SELECTED_WRITING_STYLES_KEY, JSON.stringify(styles));
}

// Add a writing style to selection
export function addSelectedWritingStyle(styleId: string) {
  const current = getSelectedWritingStyles();
  if (!current.includes(styleId)) {
    const updated = [...current, styleId];
    saveSelectedWritingStyles(updated);
    return updated;
  }
  return current;
}

// Remove a writing style from selection
export function removeSelectedWritingStyle(styleId: string) {
  const current = getSelectedWritingStyles();
  const updated = current.filter(id => id !== styleId);
  saveSelectedWritingStyles(updated);
  return updated;
}

// Check if a writing style is selected
export function isWritingStyleSelected(styleId: string): boolean {
  return getSelectedWritingStyles().includes(styleId);
}