import { supabase } from './supabase';

interface GenerationParams {
  style: string;
  prompt: string;
  length?: number;
}

interface StyleRules {
  fontFamily: string;
  letterSpacing: string;
  wordSpacing: string;
  lineHeight: string;
  textTransform?: string;
}

const styleRules: Record<string, StyleRules> = {
  uncial: {
    fontFamily: 'Uncial Antiqua',
    letterSpacing: '0.05em',
    wordSpacing: '0.2em',
    lineHeight: '2',
  },
  gothic: {
    fontFamily: 'UnifrakturMaguntia',
    letterSpacing: '0.02em',
    wordSpacing: '0.1em',
    lineHeight: '1.8',
  },
  copperplate: {
    fontFamily: 'Pinyon Script',
    letterSpacing: '0.03em',
    wordSpacing: '0.15em',
    lineHeight: '2.2',
  },
  'art-nouveau': {
    fontFamily: 'Berkshire Swash',
    letterSpacing: '0.04em',
    wordSpacing: '0.18em',
    lineHeight: '2',
  },
  modernist: {
    fontFamily: 'Inter',
    letterSpacing: '0.02em',
    wordSpacing: '0.1em',
    lineHeight: '1.6',
    textTransform: 'none'
  }
};

const stylePatterns = {
  uncial: {
    themes: ['sacred', 'ancient', 'mystical', 'eternal', 'divine'],
    vocabulary: ['ancient', 'sacred', 'eternal', 'divine', 'mystic', 'wisdom', 'holy', 'blessed'],
    settings: ['temple', 'sanctuary', 'sacred grove', 'holy mountain', 'blessed realm'],
    imagery: ['stars', 'light', 'crystal', 'gold', 'silver', 'flame']
  },
  gothic: {
    themes: ['dark', 'mysterious', 'supernatural', 'medieval', 'haunting'],
    vocabulary: ['shadow', 'dark', 'midnight', 'ghostly', 'ancient', 'mysterious', 'spectral'],
    settings: ['castle', 'cathedral', 'crypt', 'tower', 'dungeon'],
    imagery: ['moon', 'shadows', 'mist', 'stone', 'night', 'darkness']
  },
  copperplate: {
    themes: ['elegant', 'refined', 'natural', 'graceful', 'romantic'],
    vocabulary: ['grace', 'gentle', 'fair', 'sweet', 'delicate', 'refined', 'elegant'],
    settings: ['garden', 'parlor', 'manor', 'courtyard', 'pavilion'],
    imagery: ['flowers', 'fountains', 'gardens', 'sunlight', 'morning dew']
  },
  'art-nouveau': {
    themes: ['organic', 'flowing', 'natural', 'decorative', 'harmonious'],
    vocabulary: ['flowing', 'curving', 'organic', 'natural', 'harmonious', 'graceful'],
    settings: ['garden', 'forest', 'meadow', 'stream', 'glade'],
    imagery: ['vines', 'flowers', 'leaves', 'curves', 'waves', 'nature']
  },
  modernist: {
    themes: ['urban', 'geometric', 'contemporary', 'minimal', 'progressive'],
    vocabulary: ['clean', 'sharp', 'precise', 'geometric', 'modern', 'minimal'],
    settings: ['city', 'building', 'street', 'skyline', 'office'],
    imagery: ['steel', 'glass', 'concrete', 'lines', 'angles', 'light']
  }
};

export class WritingGenerator {
  private style: string;
  private maxRetries: number = 3;
  private retryDelay: number = 1000;

  constructor(style: string) {
    this.style = style;
  }

  getStyleRules(): StyleRules {
    return styleRules[this.style] || styleRules.modernist;
  }

  private adaptPromptToStyle(prompt: string): string {
    const pattern = stylePatterns[this.style as keyof typeof stylePatterns];
    if (!pattern) return prompt;

    const words = prompt.toLowerCase().split(' ');
    const title = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    
    // Select random elements from the style pattern
    const theme = pattern.themes[Math.floor(Math.random() * pattern.themes.length)];
    const vocab = pattern.vocabulary[Math.floor(Math.random() * pattern.vocabulary.length)];
    const setting = pattern.settings[Math.floor(Math.random() * pattern.settings.length)];
    const image = pattern.imagery[Math.floor(Math.random() * pattern.imagery.length)];

    // Generate verses based on the style and prompt
    return `# ${title}

[Verse 1]
In ${setting} of ${image} bright
Where ${vocab} flows through day and night
The ${theme} essence gently sings
Of ${prompt.toLowerCase()} that time now brings
Beneath the ${pattern.imagery[0]}'s eternal glow

[Chorus]
Through realms of ${theme} pure and true
Where ${vocab} dreams come into view
Each moment holds a sacred space
Where ${prompt.toLowerCase()} finds its place

[Verse 2]
The ${image} dance in patterns rare
Through ${setting} sweet beyond compare
As ${theme} wisdom gently flows
And ${vocab} beauty ever grows
In nature's endless grace

[Bridge]
Between the worlds of ${theme} light
Where ${vocab} dreams take wing in flight
The ${image} holds within its soul
The truth that makes our spirits whole

[Verse 3]
As time flows like a ${theme} stream
Through ${setting} where the ${image} gleam
We find the path that leads us home
Where ${prompt.toLowerCase()} freely roams
In life's eternal dance`;
  }

  private async saveGeneration(prompt: string, result: string): Promise<void> {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (user?.user) {
        await supabase
          .from('writing_generations')
          .insert({
            style: this.style,
            prompt,
            result
          });
      }
    } catch (error) {
      console.error('Error saving generation:', error);
    }
  }

  private async retryWithDelay(fn: () => Promise<any>, attempt: number = 1): Promise<any> {
    try {
      return await fn();
    } catch (error) {
      console.error(`Attempt ${attempt} failed:`, error);
      
      if (attempt >= this.maxRetries) {
        throw error;
      }
      
      await new Promise(resolve => setTimeout(resolve, this.retryDelay));
      return this.retryWithDelay(fn, attempt + 1);
    }
  }

  async generateText({ prompt, length = 500 }: GenerationParams): Promise<string> {
    try {
      // Generate text based on style patterns
      const generatedText = this.adaptPromptToStyle(prompt);
      
      // Save successful generation
      await this.saveGeneration(prompt, generatedText);
      
      return generatedText;
    } catch (error) {
      console.error('Error generating text:', error);
      
      // Return a simple fallback based on the style
      const fallbackText = this.adaptPromptToStyle('Untitled');
      await this.saveGeneration(prompt, fallbackText);
      return fallbackText;
    }
  }
}