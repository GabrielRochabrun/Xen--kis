import { supabase } from './supabase';
import * as Tone from 'tone';
import { Midi } from '@tonejs/midi';

// ... (keep all interfaces as is)

export class MusicGenerator {
  private temperamentId: string;
  private config: TemperamentConfig;
  private synths: Record<string, Tone.PolySynth>;
  private timeSignature: { numerator: number; denominator: number };

  constructor(temperamentId: string) {
    if (!temperamentConfigs[temperamentId]) {
      throw new Error(`Invalid temperament: ${temperamentId}`);
    }

    this.temperamentId = temperamentId;
    this.config = temperamentConfigs[temperamentId];
    this.timeSignature = { numerator: 4, denominator: 4 };
    
    // Initialize synths with better settings for each track type
    this.synths = {
      melody: new Tone.PolySynth(Tone.Synth, {
        oscillator: { type: 'sine' },
        envelope: {
          attack: 0.05,
          decay: 0.2,
          sustain: 0.6,
          release: 0.5
        }
      }).toDestination(),
      harmony: new Tone.PolySynth(Tone.FMSynth, {
        harmonicity: 2,
        modulationIndex: 3,
        envelope: {
          attack: 0.1,
          decay: 0.2,
          sustain: 0.7,
          release: 0.8
        }
      }).toDestination(),
      bass: new Tone.PolySynth(Tone.MonoSynth, {
        oscillator: { type: 'triangle' },
        envelope: {
          attack: 0.05,
          decay: 0.3,
          sustain: 0.8,
          release: 1
        },
        filterEnvelope: {
          attack: 0.05,
          decay: 0.2,
          sustain: 0.5,
          release: 2,
          baseFrequency: 200,
          octaves: 2.6
        }
      }).toDestination(),
      drums: new Tone.PolySynth(Tone.MembraneSynth, {
        pitchDecay: 0.05,
        octaves: 2,
        envelope: {
          attack: 0.001,
          decay: 0.4,
          sustain: 0.01,
          release: 1.4
        }
      }).toDestination()
    };

    // Set volumes for better mix
    this.synths.melody.volume.value = -6;
    this.synths.harmony.volume.value = -12;
    this.synths.bass.volume.value = -8;
    this.synths.drums.volume.value = -10;
  }

  // ... (keep other methods as is until playComposition)

  playComposition(composition: Composition, startTime: number = 0) {
    Tone.Transport.bpm.value = composition.tempo;
    
    composition.tracks.forEach(track => {
      const synth = this.synths[track.type];
      if (!synth) return;

      track.notes.forEach(note => {
        if ((note.time || 0) >= startTime) {
          const noteDuration = note.duration * (60 / composition.tempo);
          const frequency = this.noteToFrequency(note.pitch);
          
          if (frequency) {
            synth.triggerAttackRelease(
              frequency,
              noteDuration,
              Tone.now() + ((note.time || 0) - startTime),
              note.velocity / 127
            );
          }
        }
      });
    });
  }

  private noteToFrequency(note: string): number | null {
    // For 12-TET, use standard note names
    if (this.temperamentId === '12tet') {
      return Tone.Frequency(note).toFrequency();
    }

    // For other temperaments, calculate frequency based on note index
    const noteIndex = this.config.baseNotes.indexOf(note);
    if (noteIndex === -1) return null;

    // Calculate frequency using the temperament's division of the octave
    const semitoneRatio = Math.pow(2, 1 / this.config.divisions_per_octave);
    return this.config.baseFrequency * Math.pow(semitoneRatio, noteIndex);
  }

  // ... (keep remaining methods as is)
}