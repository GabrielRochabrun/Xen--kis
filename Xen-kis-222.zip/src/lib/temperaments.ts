// Chave para armazenar temperamentos selecionados no localStorage
const SELECTED_TEMPERAMENTS_KEY = 'selectedTemperaments';

// Função para obter temperamentos selecionados
export function getSelectedTemperaments(): string[] {
  const stored = localStorage.getItem(SELECTED_TEMPERAMENTS_KEY);
  return stored ? JSON.parse(stored) : [];
}

// Função para salvar temperamentos selecionados
export function saveSelectedTemperaments(temperaments: string[]) {
  localStorage.setItem(SELECTED_TEMPERAMENTS_KEY, JSON.stringify(temperaments));
}

// Função para adicionar um temperamento à seleção
export function addSelectedTemperament(temperamentId: string) {
  const current = getSelectedTemperaments();
  if (!current.includes(temperamentId)) {
    const updated = [...current, temperamentId];
    saveSelectedTemperaments(updated);
    return updated;
  }
  return current;
}

// Função para remover um temperamento da seleção
export function removeSelectedTemperament(temperamentId: string) {
  const current = getSelectedTemperaments();
  const updated = current.filter(id => id !== temperamentId);
  saveSelectedTemperaments(updated);
  return updated;
}

// Função para verificar se um temperamento está selecionado
export function isTemperamentSelected(temperamentId: string): boolean {
  return getSelectedTemperaments().includes(temperamentId);
}