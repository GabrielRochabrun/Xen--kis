import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Home, Music2, Download, Play, Pause, Wand2 } from 'lucide-react';
import { MusicGenerator } from '../lib/music-generator';

export default function Generator() {
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [showPlayer, setShowPlayer] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration] = useState(180); // Duração em segundos
  const [generatedContent, setGeneratedContent] = useState<{
    music?: {
      url: string;
      title: string;
    };
  }>({});

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);

    try {
      const generator = new MusicGenerator('12tet');
      await generator.initialize();
      const composition = generator.generateComposition();
      await generator.saveComposition(composition);
      setGeneratedContent({
        music: {
          url: '#', // Em uma aplicação real, seria a URL do áudio gerado
          title: composition.title
        }
      });
      setShowPlayer(true);
    } catch (error) {
      console.error('Erro na geração:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="bg-zinc-900 border-b border-zinc-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <Home className="w-5 h-5 text-gray-400" />
            </button>
            <h1 className="text-xl font-semibold text-white">Gerador Musical</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Geração de Música */}
          <div className="p-8 rounded-xl border border-zinc-800 bg-zinc-900/50 mb-12">
            <div className="flex flex-col items-center text-center gap-4">
              <Music2 className="w-12 h-12 text-zinc-400" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Gerar Música</h3>
                <p className="text-gray-400 text-sm">Crie música gerada por IA em diferentes temperamentos</p>
              </div>
            </div>
          </div>

          {/* Campo de Entrada */}
          <div className="bg-zinc-900/50 rounded-xl border border-zinc-800 p-6">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Descreva a música que você quer gerar..."
              className="w-full h-32 bg-black/50 text-white rounded-lg border border-zinc-800 p-4 focus:outline-none focus:ring-2 focus:ring-red-500/50"
            />
            <div className="mt-4 flex justify-between items-center">
              <button
                onClick={handleGenerate}
                disabled={!prompt.trim() || isGenerating}
                className={`px-6 py-3 border border-red-500 text-white rounded-lg shadow-lg transition-all flex items-center justify-center gap-2 ${
                  !prompt.trim() || isGenerating
                    ? 'opacity-50 cursor-not-allowed'
                    : 'hover:bg-red-500/10'
                }`}
              >
                <Wand2 className={`w-5 h-5 ${isGenerating ? 'animate-spin' : ''}`} />
                {isGenerating ? 'Gerando...' : 'Gerar'}
              </button>
            </div>

            {/* Exibição do Conteúdo Gerado */}
            {showPlayer && generatedContent.music && (
              <div className="mt-8">
                <div className="bg-zinc-900 rounded-lg border border-zinc-800 p-4">
                  <div className="flex items-center gap-4 mb-4">
                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="w-10 h-10 flex items-center justify-center rounded-full bg-red-600 hover:bg-red-700 transition-colors"
                    >
                      {isPlaying ? (
                        <Pause className="w-5 h-5 text-white" />
                      ) : (
                        <Play className="w-5 h-5 text-white translate-x-0.5" />
                      )}
                    </button>
                    <div className="flex-1">
                      <div className="relative">
                        <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-red-600 rounded-full transition-all duration-100"
                            style={{ width: `${(currentTime / duration) * 100}%` }}
                          />
                        </div>
                        <input
                          type="range"
                          min="0"
                          max={duration}
                          value={currentTime}
                          onChange={(e) => setCurrentTime(parseInt(e.target.value))}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                      </div>
                      <div className="flex justify-between mt-1 text-sm text-zinc-400">
                        <span>{formatTime(currentTime)}</span>
                        <span>{formatTime(duration)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Botões de Ação */}
                  <div className="flex gap-3">
                    <button
                      onClick={() => {/* Lidar com download */}}
                      className="flex-1 px-4 py-2 border border-zinc-700 hover:bg-zinc-800 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Baixar
                    </button>
                    <button
                      onClick={() => navigate('/studio')}
                      className="flex-1 px-4 py-2 border border-red-500 hover:bg-red-500/10 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                      <Music2 className="w-4 h-4" />
                      Abrir no Estúdio
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}