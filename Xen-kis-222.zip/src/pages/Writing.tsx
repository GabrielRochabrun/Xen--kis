import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, Pen, GitCompare as Compare, ChevronDown, ChevronUp, Wand2 } from 'lucide-react';
import { 
  getSelectedWritingStyles, 
  addSelectedWritingStyle, 
  removeSelectedWritingStyle 
} from '../lib/writing-styles';
import { WritingGenerator } from '../lib/writing-generator';
import Notification from '../components/Notification';

interface WritingStyle {
  id: string;
  name: string;
  description: string;
  period: string;
  characteristics: string[];
}

const writingStyles: WritingStyle[] = [
  {
    id: 'uncial',
    name: 'Uncial',
    description: 'A majuscule script used from the 4th to 8th centuries by Latin and Greek scribes. Known for its rounded forms and historical significance in religious texts.',
    period: '4th-8th century CE',
    characteristics: [
      'Round, broad letterforms',
      'Few ascenders and descenders',
      'Primarily used in religious manuscripts',
      'Clear, legible characters'
    ]
  },
  {
    id: 'gothic',
    name: 'Gothic',
    description: 'Also known as Blackletter, this style emerged in Western Europe in the 12th century. Characterized by dense, angular letterforms and elaborate decorative elements.',
    period: '12th-15th century CE',
    characteristics: [
      'Angular, compressed letters',
      'Thick vertical strokes',
      'Elaborate decorative elements',
      'Strong contrast between thick and thin lines'
    ]
  },
  {
    id: 'copperplate',
    name: 'Copperplate',
    description: 'A formal script style developed in the 16th century, characterized by its elegant, flowing lines and precise forms. Often used in formal documents and invitations.',
    period: '16th-18th century CE',
    characteristics: [
      'Elegant, flowing lines',
      'Consistent slant',
      'Formal appearance',
      'High contrast strokes'
    ]
  },
  {
    id: 'art-nouveau',
    name: 'Art Nouveau',
    description: 'A decorative style that emerged in the late 19th century, characterized by organic, flowing lines and nature-inspired forms.',
    period: 'Late 19th-early 20th century',
    characteristics: [
      'Organic, flowing forms',
      'Nature-inspired elements',
      'Decorative flourishes',
      'Asymmetrical balance'
    ]
  },
  {
    id: 'modernist',
    name: 'Modernist',
    description: 'A 20th-century style emphasizing clarity, simplicity, and geometric forms. Influenced by the Bauhaus movement and modernist principles.',
    period: '20th century',
    characteristics: [
      'Geometric forms',
      'Clean lines',
      'Minimal decoration',
      'Focus on readability'
    ]
  }
];

export default function Writing() {
  const navigate = useNavigate();
  const [selectedStyles, setSelectedStyles] = useState<string[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [notification, setNotification] = useState<{message: string; type: 'info' | 'success'} | null>(null);
  const [generatingFor, setGeneratingFor] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [generatedText, setGeneratedText] = useState<Record<string, string>>({});

  useEffect(() => {
    setSelectedStyles(getSelectedWritingStyles());
  }, []);

  const toggleSelection = (id: string) => {
    const isCurrentlySelected = selectedStyles.includes(id);
    let updatedStyles: string[];
    const style = writingStyles.find(s => s.id === id);
    
    if (isCurrentlySelected) {
      updatedStyles = removeSelectedWritingStyle(id);
      setNotification({
        message: `${style?.name} removed from selection`,
        type: 'info'
      });
    } else {
      updatedStyles = addSelectedWritingStyle(id);
      setNotification({
        message: `${style?.name} added to selection`,
        type: 'success'
      });
    }
    
    setSelectedStyles(updatedStyles);

    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const generateText = async (styleId: string) => {
    setGeneratingFor(styleId);
    const generator = new WritingGenerator(styleId);
    
    try {
      const text = await generator.generateText({ prompt });
      setGeneratedText(prev => ({
        ...prev,
        [styleId]: text
      }));
    } catch (error) {
      console.error('Error generating text:', error);
      setNotification({
        message: 'Error generating text',
        type: 'info'
      });
    }
    
    setGeneratingFor(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black">
      <header className="bg-zinc-900 border-b border-zinc-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <Home className="w-5 h-5 text-gray-400" />
            </button>
            <h1 className="text-xl font-semibold text-white">Writing Styles</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <Pen className="w-12 h-12 mx-auto text-red-500 mb-4" />
            <h1 className="text-4xl font-bold text-white mb-4">Historical Writing Styles</h1>
            <p className="text-zinc-400">Exploring the evolution of written communication through the ages</p>
          </div>

          {/* Text Generation Input */}
          <div className="mb-8">
            <div className="bg-zinc-900 rounded-xl border border-zinc-800 p-6">
              <label className="block text-sm font-medium text-zinc-400 mb-2">
                Enter your text prompt
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter text to generate in different styles..."
                className="w-full h-24 bg-black/50 text-white rounded-lg border border-zinc-800 p-4 focus:outline-none focus:ring-2 focus:ring-red-500/50"
              />
            </div>
          </div>

          <div className="space-y-6">
            {writingStyles.map(style => (
              <div
                key={style.id}
                className={`bg-zinc-900 rounded-xl border overflow-hidden transition-colors ${
                  selectedStyles.includes(style.id) ? 'border-red-500' : 'border-zinc-800'
                }`}
              >
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-white mb-2">{style.name}</h2>
                      <p className="text-zinc-500 text-sm">{style.period}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => generateText(style.id)}
                        disabled={!prompt.trim() || generatingFor === style.id}
                        className={`p-2 rounded-lg transition-colors ${
                          !prompt.trim() || generatingFor === style.id
                            ? 'text-zinc-600 cursor-not-allowed'
                            : 'hover:bg-zinc-800 text-red-500'
                        }`}
                      >
                        <Wand2 className={`w-5 h-5 ${generatingFor === style.id ? 'animate-spin' : ''}`} />
                      </button>
                      <button
                        onClick={() => toggleSelection(style.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          selectedStyles.includes(style.id)
                            ? 'bg-red-500/10 text-red-500'
                            : 'hover:bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        <Compare className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => toggleExpand(style.id)}
                        className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
                      >
                        {expandedId === style.id ? (
                          <ChevronUp className="w-5 h-5 text-zinc-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-zinc-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Generated Text */}
                  {generatedText[style.id] && (
                    <div className="mt-4 p-6 bg-black/30 rounded-lg border border-zinc-800">
                      <pre
                        className="text-white whitespace-pre-wrap"
                        style={{
                          fontFamily: new WritingGenerator(style.id).getStyleRules().fontFamily,
                          letterSpacing: new WritingGenerator(style.id).getStyleRules().letterSpacing,
                          wordSpacing: new WritingGenerator(style.id).getStyleRules().wordSpacing,
                          lineHeight: new WritingGenerator(style.id).getStyleRules().lineHeight,
                          textTransform: new WritingGenerator(style.id).getStyleRules().textTransform as any
                        }}
                      >
                        {generatedText[style.id]}
                      </pre>
                    </div>
                  )}

                  {expandedId === style.id && (
                    <div className="mt-6 space-y-6 border-t border-zinc-800 pt-6">
                      <div>
                        <h3 className="text-sm font-medium text-zinc-400 mb-2">Description</h3>
                        <p className="text-zinc-300">{style.description}</p>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium text-zinc-400 mb-3">Characteristics</h3>
                        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {style.characteristics.map((char, index) => (
                            <li 
                              key={index}
                              className="flex items-center gap-2 text-zinc-300"
                            >
                              <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                              {char}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {notification && (
        <Notification
          message={notification.message}
          type={notification.type}
          onClose={() => setNotification(null)}
        />
      )}
    </div>
  );
}