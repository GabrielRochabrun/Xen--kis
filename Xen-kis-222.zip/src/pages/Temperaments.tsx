import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, ChevronDown, ChevronUp, Filter, GitCompare as Compare, Wand2, Play, Pause, Download, Music2 } from 'lucide-react';
import Notification from '../components/Notification';
import { 
  getSelectedTemperaments, 
  addSelectedTemperament, 
  removeSelectedTemperament 
} from '../lib/temperaments';
import { MusicGenerator } from '../lib/music-generator';
import * as Tone from 'tone';

interface Temperament {
  id: string;
  name: string;
  period: string;
  definition: string;
  characteristics: string[];
  advantages: string[];
  disadvantages: string[];
  instruments: string[];
  examples: { composer: string; work: string }[];
  frequency: number;
  historicalRelevance: number;
  technicalComplexity: number;
}

const temperaments: Temperament[] = [
  {
    id: '12tet',
    name: '12-TET',
    period: 'Modern Era',
    definition: 'Twelve-tone equal temperament divides the octave into 12 equal parts, used in most modern Western music.',
    characteristics: [
      'Equal semitones',
      'Perfect for modulation',
      'Standard in modern instruments',
      'Compromise in pure intervals'
    ],
    advantages: [
      'Universal compatibility',
      'Easy modulation to any key',
      'Standard in modern music',
      'Widely understood'
    ],
    disadvantages: [
      'Less pure intervals',
      'Slight dissonance in thirds',
      'Loss of historical character',
      'Reduced harmonic richness'
    ],
    instruments: [
      'Piano',
      'Guitar',
      'Modern orchestral instruments',
      'Electronic instruments'
    ],
    examples: [
      { composer: 'Mozart', work: 'Symphony No. 40' },
      { composer: 'Beethoven', work: 'Symphony No. 9' },
      { composer: 'Chopin', work: 'Nocturnes' }
    ],
    frequency: 100,
    historicalRelevance: 90,
    technicalComplexity: 50
  },
  {
    id: '19tet',
    name: '19-TET',
    period: 'Contemporary',
    definition: 'Nineteen-tone equal temperament offers better approximations of pure intervals while maintaining practicality.',
    characteristics: [
      'More accurate thirds',
      'Extended harmonic possibilities',
      'Microtonal capabilities',
      'Complex interval relationships'
    ],
    advantages: [
      'Better pure thirds',
      'Rich harmonic texture',
      'Unique tonal colors',
      'Historical authenticity'
    ],
    disadvantages: [
      'Limited instrument availability',
      'Complex learning curve',
      'Difficult to perform',
      'Less common in practice'
    ],
    instruments: [
      'Specialized keyboards',
      'Electronic synthesizers',
      'Custom instruments',
      'Computer music'
    ],
    examples: [
      { composer: 'Yasser', work: '19-tone Compositions' },
      { composer: 'Fokker', work: 'Organ Works' }
    ],
    frequency: 30,
    historicalRelevance: 40,
    technicalComplexity: 80
  },
  {
    id: '24tet',
    name: '24-TET',
    period: 'Contemporary',
    definition: 'Quarter-tone system that divides each semitone into two equal parts, popular in contemporary music.',
    characteristics: [
      'Quarter-tone divisions',
      'Extended pitch range',
      'Modern experimental sound',
      'Microtonal precision'
    ],
    advantages: [
      'Fine pitch control',
      'Extended expression',
      'Contemporary relevance',
      'Experimental potential'
    ],
    disadvantages: [
      'Very specialized instruments needed',
      'Complex notation',
      'Difficult to perform accurately',
      'Limited repertoire'
    ],
    instruments: [
      'Quarter-tone piano',
      'Modified wind instruments',
      'Electronic instruments',
      'Specialized string instruments'
    ],
    examples: [
      { composer: 'Alois Hába', work: 'Quarter-tone Piano Pieces' },
      { composer: 'Ivan Wyschnegradsky', work: 'Quarter-tone Compositions' }
    ],
    frequency: 20,
    historicalRelevance: 30,
    technicalComplexity: 90
  },
  {
    id: '31tet',
    name: '31-TET',
    period: 'Historical/Contemporary',
    definition: 'Thirty-one-tone equal temperament provides excellent approximations of pure intervals and historical meantone temperaments.',
    characteristics: [
      'Very pure thirds',
      'Historical meantone connection',
      'Complex interval structure',
      'Extended harmonic possibilities'
    ],
    advantages: [
      'Extremely pure intervals',
      'Historical authenticity',
      'Rich harmonic possibilities',
      'Theoretical interest'
    ],
    disadvantages: [
      'Extremely specialized instruments required',
      'Very complex to perform',
      'Limited practical applications',
      'Steep learning curve'
    ],
    instruments: [
      'Fokker organ',
      'Specialized electronic instruments',
      'Computer music systems',
      'Custom-built instruments'
    ],
    examples: [
      { composer: 'Adriaan Fokker', work: '31-tone Organ Compositions' },
      { composer: 'Henk Badings', work: 'Electronic Music in 31-TET' }
    ],
    frequency: 10,
    historicalRelevance: 60,
    technicalComplexity: 100
  }
];

export default function Temperaments() {
  const navigate = useNavigate();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [selectedTemperaments, setSelectedTemperaments] = useState<string[]>([]);
  const [filterPeriod, setFilterPeriod] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'frequency' | 'historicalRelevance' | 'technicalComplexity'>('frequency');
  const [notification, setNotification] = useState<{message: string; type: 'info' | 'success'} | null>(null);
  const [generatingFor, setGeneratingFor] = useState<string | null>(null);
  const [showPlayer, setShowPlayer] = useState<Record<string, boolean>>({});
  const [isPlaying, setIsPlaying] = useState<Record<string, boolean>>({});
  const [currentTime, setCurrentTime] = useState<Record<string, number>>({});
  const [durations, setDurations] = useState<Record<string, number>>({});
  const [playbackTimers, setPlaybackTimers] = useState<Record<string, NodeJS.Timer>>({});
  const [compositions, setCompositions] = useState<Record<string, any>>({});
  const [synth, setSynth] = useState<Tone.PolySynth | null>(null);

  useEffect(() => {
    setSelectedTemperaments(getSelectedTemperaments());
    const newSynth = new Tone.PolySynth().toDestination();
    setSynth(newSynth);

    return () => {
      Object.keys(playbackTimers).forEach(id => {
        stopPlayback(id);
      });
      
      if (synth) {
        synth.dispose();
      }
    };
  }, []);

  const handleGenerate = async (temperamentId: string) => {
    if (!synth) return;
    
    setGeneratingFor(temperamentId);
    
    try {
      const generator = new MusicGenerator(temperamentId);
      await generator.initialize();
      
      const composition = generator.generateComposition();
      const duration = generator.calculateDuration(composition);
      
      setCompositions(prev => ({ ...prev, [temperamentId]: composition }));
      setDurations(prev => ({ ...prev, [temperamentId]: duration }));
      
      setShowPlayer(prev => ({ ...prev, [temperamentId]: true }));
      setCurrentTime(prev => ({ ...prev, [temperamentId]: 0 }));
      setIsPlaying(prev => ({ ...prev, [temperamentId]: false }));
      
      await generator.saveComposition(composition);
      
    } catch (error) {
      console.error('Error generating:', error);
      setNotification({
        message: 'Error generating music',
        type: 'info'
      });
    } finally {
      setGeneratingFor(null);
    }
  };

  const stopPlayback = (temperamentId: string) => {
    if (playbackTimers[temperamentId]) {
      clearInterval(playbackTimers[temperamentId]);
    }
    
    if (synth) {
      synth.releaseAll();
    }
    
    setIsPlaying(prev => ({ ...prev, [temperamentId]: false }));
    setPlaybackTimers(prev => {
      const newTimers = { ...prev };
      delete newTimers[temperamentId];
      return newTimers;
    });
  };

  const togglePlay = async (temperamentId: string) => {
    if (!synth || !compositions[temperamentId]) return;

    const composition = compositions[temperamentId];
    const duration = durations[temperamentId];

    if (!duration) {
      console.error('Duration not available');
      return;
    }

    if (isPlaying[temperamentId]) {
      stopPlayback(temperamentId);
      return;
    }

    setIsPlaying(prev => ({ ...prev, [temperamentId]: true }));
    
    const startTime = currentTime[temperamentId] || 0;
    
    const generator = new MusicGenerator(temperamentId);
    await generator.initialize();
    
    generator.playComposition(composition, startTime);

    const startTimestamp = Date.now() - (startTime * 1000);
    const timer = setInterval(() => {
      const elapsed = (Date.now() - startTimestamp) / 1000;
      
      if (elapsed >= duration) {
        stopPlayback(temperamentId);
        setCurrentTime(prev => ({ ...prev, [temperamentId]: 0 }));
      } else {
        setCurrentTime(prev => ({ ...prev, [temperamentId]: elapsed }));
      }
    }, 50);

    setPlaybackTimers(prev => ({
      ...prev,
      [temperamentId]: timer
    }));
  };

  const handleTimeUpdate = (temperamentId: string, newTime: number) => {
    if (!compositions[temperamentId]) return;

    if (isPlaying[temperamentId]) {
      stopPlayback(temperamentId);
    }

    setCurrentTime(prev => ({ ...prev, [temperamentId]: newTime }));
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const toggleSelection = (id: string) => {
    const isCurrentlySelected = selectedTemperaments.includes(id);
    let updatedTemperaments: string[];
    
    if (isCurrentlySelected) {
      updatedTemperaments = removeSelectedTemperament(id);
      setNotification({
        message: `${temperaments.find(t => t.id === id)?.name} removed from selection`,
        type: 'info'
      });
    } else {
      updatedTemperaments = addSelectedTemperament(id);
      setNotification({
        message: `${temperaments.find(t => t.id === id)?.name} added to selection`,
        type: 'success'
      });
    }
    
    setSelectedTemperaments(updatedTemperaments);
  };

  const sortedTemperaments = [...temperaments].sort((a, b) => b[sortBy] - a[sortBy]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black">
      <header className="bg-zinc-900 border-b border-zinc-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <Home className="w-5 h-5 text-gray-400" />
            </button>
            <h1 className="text-xl font-semibold text-white">Musical Temperaments</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="relative">
                <button
                  className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg hover:bg-zinc-800 transition-colors"
                >
                  <Filter className="w-4 h-4 text-zinc-400" />
                  <span className="text-zinc-400">Period: {filterPeriod}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 focus:outline-none focus:ring-2 focus:ring-red-500/50"
              >
                <option value="frequency">Frequency</option>
                <option value="historicalRelevance">Historical Relevance</option>
                <option value="technicalComplexity">Technical Complexity</option>
              </select>
            </div>
          </div>

          <div className="space-y-6">
            {sortedTemperaments.map(temperament => (
              <div
                key={temperament.id}
                className={`bg-zinc-900 rounded-xl border overflow-hidden transition-colors ${
                  selectedTemperaments.includes(temperament.id) ? 'border-red-500' : 'border-zinc-800'
                }`}
              >
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-white mb-2">{temperament.name}</h2>
                      <p className="text-zinc-500 text-sm">{temperament.period}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleGenerate(temperament.id)}
                        disabled={generatingFor === temperament.id}
                        className={`p-2 rounded-lg transition-colors ${
                          generatingFor === temperament.id
                            ? 'text-zinc-600 cursor-not-allowed'
                            : 'hover:bg-zinc-800 text-red-500'
                        }`}
                      >
                        <Wand2 className={`w-5 h-5 ${generatingFor === temperament.id ? 'animate-spin' : ''}`} />
                      </button>
                      <button
                        onClick={() => toggleSelection(temperament.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          selectedTemperaments.includes(temperament.id)
                            ? 'bg-red-500/10 text-red-500'
                            : 'hover:bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        <Compare className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => toggleExpand(temperament.id)}
                        className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
                      >
                        {expandedId === temperament.id ? (
                          <ChevronUp className="w-5 h-5 text-zinc-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-zinc-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  {showPlayer[temperament.id] && (
                    <div className="mt-4 p-4 bg-black/30 rounded-lg border border-zinc-800">
                      <div className="flex items-center gap-4">
                        <button
                          onClick={() => togglePlay(temperament.id)}
                          className="w-10 h-10 flex items-center justify-center rounded-full bg-red-600 hover:bg-red-700 transition-colors"
                        >
                          {isPlaying[temperament.id] ? (
                            <Pause className="w-5 h-5 text-white" />
                          ) : (
                            <Play className="w-5 h-5 text-white translate-x-0.5" />
                          )}
                        </button>
                        <div className="flex-1">
                          <div className="relative">
                            <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-red-600 rounded-full transition-all duration-100"
                                style={{ width: `${((currentTime[temperament.id] || 0) / (durations[temperament.id] || 1)) * 100}%` }}
                              />
                            </div>
                            <input
                              type="range"
                              min="0"
                              max={durations[temperament.id] || 0}
                              value={currentTime[temperament.id] || 0}
                              onChange={(e) => handleTimeUpdate(temperament.id, parseFloat(e.target.value))}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            />
                          </div>
                          <div className="flex justify-between mt-1 text-sm text-zinc-400">
                            <span>{formatTime(currentTime[temperament.id] || 0)}</span>
                            <span>{formatTime(durations[temperament.id] || 0)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-3 mt-4">
                        <button
                          onClick={() => {/* Handle download */}}
                          className="flex-1 px-4 py-2 border border-zinc-700 hover:bg-zinc-800 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Download
                        </button>
                        <button
                          onClick={() => navigate('/studio')}
                          className="flex-1 px-4 py-2 border border-red-500 hover:bg-red-500/10 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
                        >
                          <Music2 className="w-4 h-4" />
                          Open in Studio
                        </button>
                      </div>
                    </div>
                  )}

                  {expandedId === temperament.id && (
                    <div className="mt-6 space-y-6 border-t border-zinc-800 pt-6">
                      <div>
                        <h3 className="text-sm font-medium text-zinc-400 mb-2">Definition</h3>
                        <p className="text-zinc-300">{temperament.definition}</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h3 className="text-sm font-medium text-zinc-400 mb-3">Characteristics</h3>
                          <ul className="space-y-2">
                            {temperament.characteristics.map((char, index) => (
                              <li 
                                key={index}
                                className="flex items-center gap-2 text-zinc-300"
                              >
                                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                                {char}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h3 className="text-sm font-medium text-zinc-400 mb-3">Advantages</h3>
                          <ul className="space-y-2">
                            {temperament.advantages.map((adv, index) => (
                              <li 
                                key={index}
                                className="flex items-center gap-2 text-zinc-300"
                              >
                                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                                {adv}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h3 className="text-sm font-medium text-zinc-400 mb-3">Disadvantages</h3>
                          <ul className="space-y-2">
                            {temperament.disadvantages.map((dis, index) => (
                              <li 
                                key={index}
                                className="flex items-center gap-2 text-zinc-300"
                              >
                                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                                {dis}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h3 className="text-sm font-medium text-zinc-400 mb-3">Common Instruments</h3>
                          <ul className="space-y-2">
                            {temperament.instruments.map((inst, index) => (
                              <li 
                                key={index}
                                className="flex items-center gap-2 text-zinc-300"
                              >
                                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                                {inst}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium text-zinc-400 mb-3">Notable Examples</h3>
                        <ul className="space-y-2">
                          {temperament.examples.map((example, index) => (
                            <li 
                              key={index}
                              className="text-zinc-300"
                            >
                              <span className="font-medium">{example.composer}</span>
                              <span className="text-zinc-500"> — </span>
                              <span className="italic">{example.work}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {notification && (
        <Notification
          message={notification.message}
          type={notification.type}
          onClose={() => setNotification(null)}
        />
      )}
    </div>
  );
}