import { useNavigate } from 'react-router-dom';
import { Music2, Play, GitCompare, Pen, User } from 'lucide-react';
import { WaveformIcon } from '../components/WaveformIcon';
import { supabase } from '../lib/supabase';

export default function Home() {
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin
        }
      });

      if (error) throw error;
      
      // The user will be redirected to the OAuth provider
      console.log('Redirecting to OAuth provider...', data);
    } catch (error) {
      console.error('Error with login:', error);
    }
  };

  return (
    <div className="min-h-screen relative bg-gradient-to-br from-black via-zinc-900 to-black">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(220,38,38,0.1),transparent_50%)] animate-pulse" />
      
      {/* User Icon */}
      <div className="absolute top-4 right-4">
        <button
          onClick={handleLogin}
          className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
        >
          <User className="w-5 h-5 text-zinc-400" />
        </button>
      </div>

      <div className="relative">
        <div className="container mx-auto px-4 py-24">
          <div className="max-w-3xl mx-auto text-center">
            <div className="relative">
              <WaveformIcon className="w-24 h-24 mx-auto mb-8 text-red-600 animate-float" />
              <div className="absolute inset-0 blur-3xl bg-red-600/20 rounded-full" />
            </div>

            <h1 className="text-7xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-red-500 via-red-600 to-red-700 drop-shadow-2xl">
              Xenákis
            </h1>

            <p className="text-xl text-gray-400 mb-4 font-light italic">
              "Instinto e escolha subjetiva é o único que garante o valor de uma obra"
            </p>
            <p className="text-sm text-gray-500 mb-12">
              — Iánnis Xenákis
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => navigate('/generator')}
                className="w-auto px-6 py-3 border border-red-500 text-white rounded-lg shadow-lg hover:shadow-red-500/20 hover:bg-red-500/10 transition-all flex items-center justify-center gap-2 group"
              >
                <Music2 className="w-5 h-5 group-hover:animate-bounce" />
                AI
              </button>
              
              <button
                onClick={() => navigate('/studio')}
                className="w-auto px-6 py-3 border border-red-500 text-white rounded-lg shadow-lg hover:shadow-red-500/20 hover:bg-red-500/10 transition-all flex items-center justify-center gap-2 group"
              >
                <Play className="w-5 h-5 group-hover:animate-pulse" />
                Studio
              </button>

              <button
                onClick={() => navigate('/temperaments')}
                className="w-auto px-6 py-3 border border-red-500 text-white rounded-lg shadow-lg hover:shadow-red-500/20 hover:bg-red-500/10 transition-all flex items-center justify-center gap-2 group"
              >
                <GitCompare className="w-5 h-5 group-hover:animate-pulse" />
                Temperaments
              </button>

              <button
                onClick={() => navigate('/writing')}
                className="w-auto px-6 py-3 border border-red-500 text-white rounded-lg shadow-lg hover:shadow-red-500/20 hover:bg-red-500/10 transition-all flex items-center justify-center gap-2 group"
              >
                <Pen className="w-5 h-5 group-hover:animate-pulse" />
                Writing
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}