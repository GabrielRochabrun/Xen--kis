import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import * as Tone from 'tone';
import { 
  Settings, 
  Clock, 
  Music, 
  Play,
  Plus,
  User,
  Square,
  Drum,
  Piano,
  Guitar,
  Waves
} from 'lucide-react';
import PianoRoll from '../components/PianoRoll';
import AuthModal from '../components/AuthModal';

export default function Studio() {
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(false);
  const [bpm, setBpm] = useState(120);
  const [timeSignature, setTimeSignature] = useState({ numerator: 4, denominator: 4 });
  const [showTrackMenu, setShowTrackMenu] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [trackOrder, setTrackOrder] = useState<string[]>([]);
  const [audioStarted, setAudioStarted] = useState(false);

  const availableTracks = {
    drums: {
      id: 'drums',
      name: 'Drums',
      synth: new Tone.PolySynth(Tone.MembraneSynth).toDestination(),
      color: 'rgb(239, 68, 68)',
      isLoading: false,
      isReady: true
    },
    bass: {
      id: 'bass',
      name: 'Bass',
      synth: new Tone.PolySynth(Tone.FMSynth).toDestination(),
      color: 'rgb(239, 68, 68)',
      isLoading: false,
      isReady: true
    },
    piano: {
      id: 'piano',
      name: 'Piano',
      synth: new Tone.PolySynth().toDestination(),
      color: 'rgb(239, 68, 68)',
      isLoading: false,
      isReady: true
    },
    guitar: {
      id: 'guitar',
      name: 'Guitar',
      synth: new Tone.PolySynth(Tone.AMSynth).toDestination(),
      color: 'rgb(239, 68, 68)',
      isLoading: false,
      isReady: true
    }
  };

  const trackTypes = [
    { id: 'drums', name: 'Drums', icon: Drum },
    { id: 'bass', name: 'Bass', icon: Waves },
    { id: 'piano', name: 'Piano', icon: Piano },
    { id: 'guitar', name: 'Guitar', icon: Guitar },
  ];

  const addTrack = async (trackId: string) => {
    if (!audioStarted) {
      await Tone.start();
      setAudioStarted(true);
    }
    if (!trackOrder.includes(trackId)) {
      setTrackOrder(prev => [...prev, trackId]);
    }
    setShowTrackMenu(false);
  };

  const removeTrack = (trackId: string) => {
    setTrackOrder(prev => prev.filter(id => id !== trackId));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black flex flex-col">
      {/* Main Header */}
      <header className="bg-zinc-900/95 border-b border-zinc-800">
        <div className="flex items-center justify-between px-4 h-14">
          {/* Left section */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2"
            >
              <Music className="w-5 h-5 text-red-500" />
              <span className="text-white font-semibold">Xenákis</span>
            </button>
            <span className="text-zinc-600">|</span>
            <span className="text-zinc-400 text-sm">Untitled Project</span>
            <span className="text-zinc-500 text-sm">Last saved: Just now</span>
          </div>

          {/* Right section */}
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-zinc-800 rounded-lg transition-colors">
              <Settings className="w-5 h-5 text-zinc-400" />
            </button>
            <button 
              onClick={() => setShowAuthModal(true)}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <User className="w-5 h-5 text-zinc-400" />
            </button>
          </div>
        </div>
      </header>

      {/* Transport Controls */}
      <div className="bg-zinc-900/90 border-b border-zinc-800">
        <div className="flex items-center justify-between px-4 h-12">
          {/* Transport Controls */}
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-red-600 hover:bg-red-700 transition-colors"
            >
              {isPlaying ? <Square className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white" />}
            </button>

            <div className="flex items-center gap-2 border-l border-zinc-800 pl-4">
              <select 
                value={timeSignature.numerator}
                onChange={(e) => setTimeSignature(prev => ({ ...prev, numerator: parseInt(e.target.value) }))}
                className="bg-zinc-800 text-white text-sm px-2 py-1 rounded border border-zinc-700 focus:outline-none focus:ring-1 focus:ring-red-500"
              >
                {Array.from({ length: 16 }, (_, i) => i + 1).map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </select>
              <span className="text-zinc-400">/</span>
              <select 
                value={timeSignature.denominator}
                onChange={(e) => setTimeSignature(prev => ({ ...prev, denominator: parseInt(e.target.value) }))}
                className="bg-zinc-800 text-white text-sm px-2 py-1 rounded border border-zinc-700 focus:outline-none focus:ring-1 focus:ring-red-500"
              >
                {[2, 4, 8, 16].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 border-l border-zinc-800 pl-4">
              <Clock className="w-4 h-4 text-zinc-400" />
              <span className="font-mono text-white">0:00.0</span>
            </div>

            <div className="flex items-center gap-2 border-l border-zinc-800 pl-4">
              <span className="text-zinc-400 text-sm">BPM</span>
              <input 
                type="number" 
                value={bpm}
                onChange={(e) => setBpm(Math.max(0, Math.min(300, parseInt(e.target.value) || 0)))}
                className="w-16 bg-zinc-800 text-white text-sm px-2 py-1 rounded border border-zinc-700 focus:outline-none focus:ring-1 focus:ring-red-500"
              />
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-4 relative">
            <button 
              onClick={() => setShowTrackMenu(!showTrackMenu)}
              className="px-3 py-1.5 border border-red-500 hover:bg-red-500/10 text-white text-sm rounded-lg transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Track
            </button>

            {/* Track Selection Menu */}
            {showTrackMenu && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-zinc-900 border border-zinc-800 rounded-lg shadow-xl overflow-hidden z-50">
                {trackTypes.map((track) => {
                  const Icon = track.icon;
                  return (
                    <button
                      key={track.id}
                      onClick={() => addTrack(track.id)}
                      className="w-full px-4 py-3 flex items-center gap-3 hover:bg-zinc-800 transition-colors text-left"
                    >
                      <Icon className="w-5 h-5 text-red-500" />
                      <span className="text-white text-sm">{track.name}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        <PianoRoll 
          trackOrder={trackOrder}
          availableTracks={availableTracks}
          isPlaying={isPlaying}
          bpm={bpm}
          timeSignature={timeSignature}
          onRemoveTrack={removeTrack}
        />
      </main>

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </div>
  );
}