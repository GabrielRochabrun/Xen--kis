import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Studio from './pages/Studio';
import Generator from './pages/Generator';
import Temperaments from './pages/Temperaments';
import Writing from './pages/Writing';
import SelectedTemperaments from './components/SelectedTemperaments';
import SelectedStyles from './components/SelectedStyles';

function App() {
  return (
    <BrowserRouter>
      <SelectedTemperaments />
      <SelectedStyles />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/studio" element={<Studio />} />
        <Route path="/generator" element={<Generator />} />
        <Route path="/temperaments" element={<Temperaments />} />
        <Route path="/writing" element={<Writing />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;