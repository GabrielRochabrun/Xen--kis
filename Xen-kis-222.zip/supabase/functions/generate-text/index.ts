import { serve } from 'https://deno.fresh.dev/std@0.168.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const stylePatterns = {
  uncial: `# Sacred Waters

[Verse 1]
In ancient pools of crystal light
Where wisdom flows through day and night
The sacred waters gently sing
Of mysteries that time doth bring
Beneath the stars' eternal glow`,

  gothic: `# Shadows of the Night

[Verse 1]
In chambers dark where shadows creep
Through ancient halls where secrets keep
The midnight hour strikes its toll
As darkness claims each restless soul
Beneath the moon's pale, ghostly light`,

  copperplate: `# Garden of Elegance

[Verse 1]
In gardens fair where roses bloom
With grace bestowed by nature's loom
Each petal falls with gentle art
To touch the morning's dewy heart
Beneath the summer's golden rays`,

  'art-nouveau': `# Nature's Dance

[Verse 1]
In flowing lines of leaf and vine
Where nature's art and dreams entwine
The morning glories gently sway
As sunlight greets the breaking day
In patterns ever new and free`,

  modernist: `# Urban Rhythms

[Verse 1]
Steel and glass cut clean and sharp
Against the city's beating heart
Geometric forms align
In patterns stark and crystalline
Through urban canyons deep`
};

function generateFallbackText(style: string, prompt: string): string {
  const pattern = stylePatterns[style as keyof typeof stylePatterns] || stylePatterns.modernist;
  const title = prompt.split(' ').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
  ).join(' ');

  return pattern.replace(/^#.*$/m, `# ${title}`);
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { style, prompt } = await req.json();

    if (!style || !prompt) {
      throw new Error('Style and prompt are required');
    }

    // Generate fallback text
    const fallbackText = generateFallbackText(style, prompt);

    // Return the fallback text with success status
    return new Response(
      JSON.stringify({ 
        text: fallbackText,
        fallback: true
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );

  } catch (error) {
    console.error('Error:', error);
    
    // Return error response with fallback text
    return new Response(
      JSON.stringify({ 
        error: error.message,
        text: generateFallbackText('modernist', 'Untitled'),
        fallback: true
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});