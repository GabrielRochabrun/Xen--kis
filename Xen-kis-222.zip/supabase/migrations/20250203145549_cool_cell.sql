/*
  # Fix Writing Generations Schema

  1. Changes
    - Drop and recreate writing_generations table with proper schema
    - Set up correct permissions and policies
    - Enable RLS with proper policies
    - Grant necessary schema access

  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Set proper schema permissions
*/

-- First, ensure we have the correct schema permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- Recreate the writing_generations table
DROP TABLE IF EXISTS public.writing_generations;

CREATE TABLE public.writing_generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  style text NOT NULL,
  prompt text NOT NULL,
  result text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.writing_generations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can create writing generations"
  ON public.writing_generations 
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view writing generations"
  ON public.writing_generations
  FOR SELECT
  TO authenticated
  USING (true);

-- Grant table permissions
GRANT ALL ON public.writing_generations TO authenticated;
GRANT SELECT ON public.writing_generations TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;