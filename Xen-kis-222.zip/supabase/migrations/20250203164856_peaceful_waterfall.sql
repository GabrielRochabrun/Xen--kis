-- Reset schema permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- Set search paths for all roles
ALTER ROLE postgres SET search_path TO public;
ALTER ROLE anon SET search_path TO public;
ALTER ROLE authenticated SET search_path TO public;
ALTER ROLE service_role SET search_path TO public;

-- Grant table permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;

-- Grant sequence permissions
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO postgres, authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Ensure RLS is enabled
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Update policies
DROP POLICY IF EXISTS "Public read access" ON public.temperaments;
CREATE POLICY "Public read access"
  ON public.temperaments
  FOR SELECT
  TO PUBLIC
  USING (true);

DROP POLICY IF EXISTS "Authenticated user access" ON public.compositions;
CREATE POLICY "Authenticated user access"
  ON public.compositions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Set search path for current session
SET search_path TO public;

-- Ensure schema is exposed in database
ALTER DATABASE postgres SET search_path TO public;

-- CRITICAL: Expose schema to PostgREST
ALTER ROLE authenticator SET pgrst.db_schemas TO 'public';
ALTER ROLE anon SET pgrst.db_schemas TO 'public';
ALTER ROLE authenticated SET pgrst.db_schemas TO 'public';