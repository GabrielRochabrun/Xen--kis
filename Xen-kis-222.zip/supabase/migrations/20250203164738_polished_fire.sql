-- Insert complete temperament data
INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave)
VALUES 
  ('12tet', 'Twelve-tone equal temperament', 
   'Standard 12-tone equal temperament used in most modern music. This is the most common tuning system used today, dividing the octave into twelve equal parts.',
   ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
   440.0, 12),
  ('19tet', 'Nineteen-tone equal temperament',
   'Extended tuning system with 19 equal divisions of the octave. Provides better approximations of pure thirds while maintaining practical usability.',
   ARRAY['C', 'C+', 'C#', 'C#+', 'D', 'D+', 'D#', 'D#+', 'E', 'F', 'F+', 'F#', 'F#+', 'G', 'G+', 'G#', 'G#+', 'A', 'A+'],
   440.0, 19),
  ('24tet', 'Twenty-four-tone equal temperament',
   'Quarter-tone system dividing each semitone into two equal parts. Popular in contemporary and experimental music for its microtonal possibilities.',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'B'],
   440.0, 24),
  ('31tet', 'Thirty-one-tone equal temperament',
   'Advanced microtonal system with 31 equal divisions of the octave. Provides excellent approximations of pure intervals and historical meantone temperaments.',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'E+', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'A#', 'A#↑', 'B↓', 'B', 'B+', 'B#', 'B#↑'],
   440.0, 31)
ON CONFLICT (id) DO UPDATE 
SET 
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  notes = EXCLUDED.notes,
  base_frequency = EXCLUDED.base_frequency,
  divisions_per_octave = EXCLUDED.divisions_per_octave;