/*
  # Fix Schema Permissions and Policies

  1. Changes
    - Reset schema permissions
    - Add public schema access for anon and authenticated roles
    - Update RLS policies for public access
    - Ensure proper table grants

  2. Security
    - Enable RLS on all tables
    - Set up proper public access policies
    - Maintain data security with appropriate grants

  3. Notes
    - Fixes PGRST106 error by properly configuring schema access
    - Ensures public read access to temperaments
    - Maintains secure access control
*/

-- Reset schema permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- Grant table access
GRANT SELECT ON public.temperaments TO anon;
GRANT SELECT ON public.temperaments TO authenticated;
GRANT ALL ON public.compositions TO authenticated;

-- Update RLS policies
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view temperaments" ON public.temperaments;
CREATE POLICY "Public can view temperaments"
  ON public.temperaments
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Grant sequence usage
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- Ensure public schema is exposed
ALTER ROLE anon SET search_path = public;
ALTER ROLE authenticated SET search_path = public;

-- Verify temperaments exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM public.temperaments WHERE id = '12tet'
  ) THEN
    INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave) VALUES
      ('12tet', 'Twelve-tone equal temperament', 
       'Standard 12-tone equal temperament used in most modern music',
       ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
       440.0, 12);
  END IF;
END $$;