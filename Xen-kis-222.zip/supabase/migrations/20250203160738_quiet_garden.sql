-- Reset schema permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS public.compositions;
DROP TABLE IF EXISTS public.temperaments;

-- Create temperaments table
CREATE TABLE public.temperaments (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  notes text[] NOT NULL,
  base_frequency float NOT NULL,
  divisions_per_octave integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create compositions table
CREATE TABLE public.compositions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  temperament_id text REFERENCES public.temperaments NOT NULL,
  title text NOT NULL,
  chords jsonb NOT NULL,
  melody jsonb NOT NULL,
  tempo integer NOT NULL DEFAULT 120,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Create simple policies
DROP POLICY IF EXISTS "Public read access" ON public.temperaments;
CREATE POLICY "Public read access"
  ON public.temperaments
  FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Authenticated user access" ON public.compositions;
CREATE POLICY "Authenticated user access"
  ON public.compositions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Grant schema access
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;

-- Grant table permissions
GRANT ALL ON public.temperaments TO authenticated;
GRANT SELECT ON public.temperaments TO anon;
GRANT ALL ON public.compositions TO authenticated;

-- Grant sequence permissions
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- Insert default temperament
INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave)
VALUES 
  ('12tet', 'Twelve-tone equal temperament', 
   'Standard 12-tone equal temperament used in most modern music',
   ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
   440.0, 12);

-- Set search path
SET search_path TO public;