/*
  # Update writing generations schema and policies

  1. Schema Changes
    - Create writing_generations table if it doesn't exist
    - Add policies if they don't exist
  
  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

DO $$ 
BEGIN
  -- Create table if it doesn't exist
  IF NOT EXISTS (
    SELECT FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'writing_generations'
  ) THEN
    CREATE TABLE writing_generations (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      style text NOT NULL,
      prompt text NOT NULL,
      result text NOT NULL,
      created_at timestamptz DEFAULT now()
    );
  END IF;

  -- Enable RLS
  ALTER TABLE writing_generations ENABLE ROW LEVEL SECURITY;

  -- Create policies if they don't exist
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'writing_generations' 
    AND policyname = 'Anyone can create writing generations'
  ) THEN
    CREATE POLICY "Anyone can create writing generations"
      ON writing_generations FOR INSERT
      TO authenticated
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'writing_generations' 
    AND policyname = 'Anyone can view writing generations'
  ) THEN
    CREATE POLICY "Anyone can view writing generations"
      ON writing_generations FOR SELECT
      TO authenticated
      USING (true);
  END IF;
END $$;