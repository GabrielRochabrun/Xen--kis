/*
  # Music Generator Schema

  1. New Tables
    - `temperaments`
      - `id` (uuid, primary key)
      - `name` (text) - Nome do temperamento (12-TET, 19-TET, etc)
      - `description` (text) - Descrição do temperamento
      - `notes` (text[]) - Array de notas disponíveis
      - `base_frequency` (float) - Frequência base (A4 = 440Hz)
      - `divisions_per_octave` (integer) - Número de divisões por oitava
      - `created_at` (timestamp)

    - `compositions`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - Referência ao usuário que criou
      - `temperament_id` (uuid) - Referência ao temperamento usado
      - `title` (text) - Título da composição
      - `chords` (jsonb) - Progressão de acordes
      - `melody` (jsonb) - Notas da melodia
      - `tempo` (integer) - BPM da composição
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Policies para leitura/escrita de compositions
    - Policies para leitura de temperaments
*/

-- Create temperaments table
CREATE TABLE temperaments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  notes text[] NOT NULL,
  base_frequency float NOT NULL,
  divisions_per_octave integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create compositions table
CREATE TABLE compositions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  temperament_id uuid REFERENCES temperaments NOT NULL,
  title text NOT NULL,
  chords jsonb NOT NULL,
  melody jsonb NOT NULL,
  tempo integer NOT NULL DEFAULT 120,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE compositions ENABLE ROW LEVEL SECURITY;

-- Policies for temperaments (read-only for all)
CREATE POLICY "Temperaments are viewable by everyone" 
  ON temperaments FOR SELECT 
  TO authenticated 
  USING (true);

-- Policies for compositions
CREATE POLICY "Users can create their own compositions" 
  ON compositions FOR INSERT 
  TO authenticated 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own compositions" 
  ON compositions FOR SELECT 
  TO authenticated 
  USING (auth.uid() = user_id);

-- Insert default temperaments
INSERT INTO temperaments (name, description, notes, base_frequency, divisions_per_octave) VALUES
  ('12-TET', 'Twelve-tone equal temperament', 
   ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
   440.0, 12),
  ('19-TET', 'Nineteen-tone equal temperament',
   ARRAY['C', 'C+', 'C#', 'C#+', 'D', 'D+', 'D#', 'D#+', 'E', 'F', 'F+', 'F#', 'F#+', 'G', 'G+', 'G#', 'G#+', 'A', 'A+'],
   440.0, 19),
  ('24-TET', 'Twenty-four-tone equal temperament',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'B'],
   440.0, 24),
  ('31-TET', 'Thirty-one-tone equal temperament',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'E+', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'A#', 'A#↑', 'B↓', 'B', 'B+', 'B#', 'B#↑'],
   440.0, 31);