/*
  # Update Musical Temperaments Schema

  1. Changes
    - Safely create or update temperaments and compositions tables
    - Add RLS policies
    - Insert default temperaments
    
  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Grant necessary permissions
*/

-- First, ensure we have the correct schema permissions
DO $$ 
BEGIN
  -- Drop existing tables if they exist
  DROP TABLE IF EXISTS public.compositions;
  DROP TABLE IF EXISTS public.temperaments;

  -- Create temperaments table
  CREATE TABLE public.temperaments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    description text,
    notes text[] NOT NULL,
    base_frequency float NOT NULL,
    divisions_per_octave integer NOT NULL,
    created_at timestamptz DEFAULT now()
  );

  -- Create compositions table
  CREATE TABLE public.compositions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users NOT NULL,
    temperament_id uuid REFERENCES public.temperaments NOT NULL,
    title text NOT NULL,
    chords jsonb NOT NULL,
    melody jsonb NOT NULL,
    tempo integer NOT NULL DEFAULT 120,
    created_at timestamptz DEFAULT now()
  );

  -- Enable RLS
  ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
  ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Temperaments are viewable by everyone"
    ON public.temperaments
    FOR SELECT
    TO authenticated
    USING (true);

  CREATE POLICY "Users can create their own compositions"
    ON public.compositions
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

  CREATE POLICY "Users can view their own compositions"
    ON public.compositions
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

  -- Grant permissions
  GRANT ALL ON public.temperaments TO authenticated;
  GRANT SELECT ON public.temperaments TO anon;
  GRANT ALL ON public.compositions TO authenticated;
  GRANT SELECT ON public.compositions TO anon;

  -- Insert default temperaments
  INSERT INTO public.temperaments (name, description, notes, base_frequency, divisions_per_octave) VALUES
    ('12-TET', 'Twelve-tone equal temperament', 
     ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
     440.0, 12),
    ('19-TET', 'Nineteen-tone equal temperament',
     ARRAY['C', 'C+', 'C#', 'C#+', 'D', 'D+', 'D#', 'D#+', 'E', 'F', 'F+', 'F#', 'F#+', 'G', 'G+', 'G#', 'G#+', 'A', 'A+'],
     440.0, 19),
    ('24-TET', 'Twenty-four-tone equal temperament',
     ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'B'],
     440.0, 24),
    ('31-TET', 'Thirty-one-tone equal temperament',
     ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'E+', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'A#', 'A#↑', 'B↓', 'B', 'B+', 'B#', 'B#↑'],
     440.0, 31);

EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error occurred: %', SQLERRM;
END $$;