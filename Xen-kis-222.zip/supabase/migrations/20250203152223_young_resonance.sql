/*
  # Fix Schema Permissions and Public Access

  1. Changes
    - Reset and properly configure schema permissions
    - Ensure public schema is accessible
    - Set up proper RLS policies
    - Configure correct role search paths

  2. Security
    - Maintain RLS protection
    - Allow public read access to temperaments
    - Restrict composition access appropriately

  3. Notes
    - Fixes PGRST106 error by properly exposing the public schema
    - Ensures proper access control while maintaining security
*/

-- Reset schema permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- Set search paths for roles
ALTER ROLE anon SET search_path TO public;
ALTER ROLE authenticated SET search_path TO public;
ALTER ROLE service_role SET search_path TO public;

-- Grant table permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;

-- Grant sequence permissions
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO postgres, authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Ensure RLS is enabled
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Update policies for public access
DROP POLICY IF EXISTS "Public can view temperaments" ON public.temperaments;
CREATE POLICY "Public can view temperaments"
  ON public.temperaments
  FOR SELECT
  USING (true);

-- Ensure proper ownership
ALTER TABLE public.temperaments OWNER TO postgres;
ALTER TABLE public.compositions OWNER TO postgres;

-- Verify temperaments exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM public.temperaments WHERE id = '12tet'
  ) THEN
    INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave) VALUES
      ('12tet', 'Twelve-tone equal temperament', 
       'Standard 12-tone equal temperament used in most modern music',
       ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
       440.0, 12);
  END IF;
END $$;