/*
  # Fix schema permissions for writing generations

  1. Schema Changes
    - Ensure public schema is accessible
    - Grant proper permissions to roles
  
  2. Security
    - Set up proper schema access
    - Update RLS policies
*/

-- Enable access to public schema
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- Grant access to the sequence
ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT ALL ON SEQUENCES TO postgres, anon, authenticated, service_role;

-- Grant table permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;

-- Recreate the writing_generations table with proper schema
DO $$ 
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Anyone can create writing generations" ON public.writing_generations;
  DROP POLICY IF EXISTS "Anyone can view writing generations" ON public.writing_generations;
  
  -- Recreate table if it doesn't exist
  IF NOT EXISTS (
    SELECT FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'writing_generations'
  ) THEN
    CREATE TABLE public.writing_generations (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      style text NOT NULL,
      prompt text NOT NULL,
      result text NOT NULL,
      created_at timestamptz DEFAULT now()
    );
  END IF;

  -- Enable RLS
  ALTER TABLE public.writing_generations ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Anyone can create writing generations"
    ON public.writing_generations FOR INSERT
    TO authenticated
    WITH CHECK (true);

  CREATE POLICY "Anyone can view writing generations"
    ON public.writing_generations FOR SELECT
    TO authenticated
    USING (true);
END $$;