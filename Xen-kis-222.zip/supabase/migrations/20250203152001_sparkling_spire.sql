/*
  # Fix Schema and Tables Setup

  1. Changes
    - Drop and recreate tables with proper schema setup
    - Add proper grants and permissions
    - Enable RLS with correct policies
    - Insert default temperaments data

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies for authenticated users
    - Set up proper grants for public schema

  3. Notes
    - Uses IF EXISTS checks for safety
    - Includes all necessary permissions
    - Maintains data consistency
*/

-- Reset and setup schema permissions
DROP POLICY IF EXISTS "Temperaments are viewable by everyone" ON public.temperaments;
DROP POLICY IF EXISTS "Users can create their own compositions" ON public.compositions;
DROP POLICY IF EXISTS "Users can view their own compositions" ON public.compositions;

-- Drop tables if they exist
DROP TABLE IF EXISTS public.compositions;
DROP TABLE IF EXISTS public.temperaments;

-- Create temperaments table
CREATE TABLE public.temperaments (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  notes text[] NOT NULL,
  base_frequency float NOT NULL,
  divisions_per_octave integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create compositions table
CREATE TABLE public.compositions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  temperament_id text REFERENCES public.temperaments NOT NULL,
  title text NOT NULL,
  chords jsonb NOT NULL,
  melody jsonb NOT NULL,
  tempo integer NOT NULL DEFAULT 120,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public can view temperaments"
  ON public.temperaments
  FOR SELECT
  USING (true);

CREATE POLICY "Users can create their own compositions"
  ON public.compositions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own compositions"
  ON public.compositions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Grant schema permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- Grant table permissions
GRANT ALL ON public.temperaments TO authenticated;
GRANT SELECT ON public.temperaments TO anon;
GRANT ALL ON public.compositions TO authenticated;
GRANT SELECT ON public.compositions TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Insert default temperaments
INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave) VALUES
  ('12tet', 'Twelve-tone equal temperament', 
   'Standard 12-tone equal temperament used in most modern music',
   ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
   440.0, 12),
  ('19tet', 'Nineteen-tone equal temperament',
   'Extended tuning system with 19 equal divisions of the octave',
   ARRAY['C', 'C+', 'C#', 'C#+', 'D', 'D+', 'D#', 'D#+', 'E', 'F', 'F+', 'F#', 'F#+', 'G', 'G+', 'G#', 'G#+', 'A', 'A+'],
   440.0, 19),
  ('24tet', 'Twenty-four-tone equal temperament',
   'Quarter-tone system with 24 equal divisions of the octave',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'B'],
   440.0, 24),
  ('31tet', 'Thirty-one-tone equal temperament',
   'Advanced microtonal system with 31 equal divisions of the octave',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'E+', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'A#', 'A#↑', 'B↓', 'B', 'B+', 'B#', 'B#↑'],
   440.0, 31);