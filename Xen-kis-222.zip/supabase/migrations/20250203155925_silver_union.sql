/*
  # Fix schema permissions and access

  1. Schema Setup
    - Reset all permissions
    - Grant proper schema access
    - Set search paths
  
  2. Table Setup
    - Recreate tables with proper permissions
    - Enable RLS
    - Set up policies
*/

-- Reset all permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- Set search paths
ALTER ROLE anon SET search_path TO public;
ALTER ROLE authenticated SET search_path TO public;
ALTER ROLE service_role SET search_path TO public;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS public.compositions;
DROP TABLE IF EXISTS public.temperaments;

-- Create temperaments table
CREATE TABLE public.temperaments (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  notes text[] NOT NULL,
  base_frequency float NOT NULL,
  divisions_per_octave integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create compositions table
CREATE TABLE public.compositions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  temperament_id text REFERENCES public.temperaments NOT NULL,
  title text NOT NULL,
  chords jsonb NOT NULL,
  melody jsonb NOT NULL,
  tempo integer NOT NULL DEFAULT 120,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Create policies with explicit TO clauses
DROP POLICY IF EXISTS "Anyone can view temperaments" ON public.temperaments;
CREATE POLICY "Anyone can view temperaments"
  ON public.temperaments
  FOR SELECT
  TO anon, authenticated, service_role
  USING (true);

DROP POLICY IF EXISTS "Users can create their own compositions" ON public.compositions;
CREATE POLICY "Users can create their own compositions"
  ON public.compositions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can view their own compositions" ON public.compositions;
CREATE POLICY "Users can view their own compositions"
  ON public.compositions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Grant table permissions
GRANT ALL ON public.temperaments TO postgres;
GRANT ALL ON public.temperaments TO authenticated;
GRANT ALL ON public.temperaments TO service_role;
GRANT SELECT ON public.temperaments TO anon;

GRANT ALL ON public.compositions TO postgres;
GRANT ALL ON public.compositions TO authenticated;
GRANT ALL ON public.compositions TO service_role;
GRANT SELECT ON public.compositions TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO postgres;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO service_role;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Insert default temperaments
INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave) VALUES
  ('12tet', 'Twelve-tone equal temperament', 
   'Standard 12-tone equal temperament used in most modern music',
   ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
   440.0, 12),
  ('19tet', 'Nineteen-tone equal temperament',
   'Extended tuning system with 19 equal divisions of the octave',
   ARRAY['C', 'C+', 'C#', 'C#+', 'D', 'D+', 'D#', 'D#+', 'E', 'F', 'F+', 'F#', 'F#+', 'G', 'G+', 'G#', 'G#+', 'A', 'A+'],
   440.0, 19),
  ('24tet', 'Twenty-four-tone equal temperament',
   'Quarter-tone system with 24 equal divisions of the octave',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'B'],
   440.0, 24),
  ('31tet', 'Thirty-one-tone equal temperament',
   'Advanced microtonal system with 31 equal divisions of the octave',
   ARRAY['C', 'C+', 'C#', 'C#↑', 'D↓', 'D', 'D+', 'D#', 'D#↑', 'E↓', 'E', 'E+', 'F', 'F+', 'F#', 'F#↑', 'G↓', 'G', 'G+', 'G#', 'G#↑', 'A↓', 'A', 'A+', 'A#', 'A#↑', 'B↓', 'B', 'B+', 'B#', 'B#↑'],
   440.0, 31);

-- Ensure schema is exposed
ALTER DATABASE postgres SET search_path TO public;

-- Reset search path for current session
SET search_path TO public;