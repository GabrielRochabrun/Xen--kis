/*
  # Add writing generations table

  1. New Tables
    - `writing_generations`
      - `id` (uuid, primary key)
      - `style` (text)
      - `prompt` (text)
      - `result` (text)
      - `created_at` (timestamp)
  2. Security
    - Enable RLS on `writing_generations` table
    - Add policy for authenticated users to create generations
*/

-- Create writing generations table
CREATE TABLE writing_generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  style text NOT NULL,
  prompt text NOT NULL,
  result text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE writing_generations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can create writing generations"
  ON writing_generations FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view writing generations"
  ON writing_generations FOR SELECT
  TO authenticated
  USING (true);