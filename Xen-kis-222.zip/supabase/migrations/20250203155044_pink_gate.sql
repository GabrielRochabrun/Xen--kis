-- Check if policy exists before dropping
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'temperaments' 
    AND policyname = 'Public can view temperaments'
  ) THEN
    DROP POLICY "Public can view temperaments" ON public.temperaments;
  END IF;
END $$;

-- Create or update policy
CREATE POLICY "Public can view temperaments"
  ON public.temperaments
  FOR SELECT
  USING (true);

-- Ensure RLS is enabled
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions if they don't exist
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON public.temperaments TO anon, authenticated;
GRANT ALL ON public.compositions TO authenticated;
GRANT SELECT ON public.compositions TO anon;