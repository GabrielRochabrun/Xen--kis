-- Reset schema permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- Set search paths for all roles
ALTER ROLE postgres SET search_path TO public;
ALTER ROLE anon SET search_path TO public;
ALTER ROLE authenticated SET search_path TO public;
ALTER ROLE service_role SET search_path TO public;

-- Grant table permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;

-- Grant sequence permissions
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO postgres, authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Ensure RLS is enabled
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Update policies
DROP POLICY IF EXISTS "Public read access" ON public.temperaments;
CREATE POLICY "Public read access"
  ON public.temperaments
  FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "Authenticated user access" ON public.compositions;
CREATE POLICY "Authenticated user access"
  ON public.compositions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Set search path for current session
SET search_path TO public;

-- Ensure schema is exposed in database
ALTER DATABASE postgres SET search_path TO public;

-- Verify temperaments exist and recreate if needed
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM public.temperaments WHERE id = '12tet'
  ) THEN
    INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave)
    VALUES 
      ('12tet', 'Twelve-tone equal temperament', 
       'Standard 12-tone equal temperament used in most modern music',
       ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
       440.0, 12);
  END IF;
END $$;