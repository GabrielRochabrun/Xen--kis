-- Reset schema permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM public;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM public;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM public;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Set search paths
ALTER ROLE anon SET search_path TO public;
ALTER ROLE authenticated SET search_path TO public;
ALTER ROLE service_role SET search_path TO public;

-- Grant table permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Ensure RLS is enabled
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Update policies for public access
DROP POLICY IF EXISTS "Public can view temperaments" ON public.temperaments;
CREATE POLICY "Public can view temperaments"
  ON public.temperaments
  FOR SELECT
  USING (true);

-- Verify and update temperaments if needed
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM public.temperaments WHERE id = '12tet'
  ) THEN
    INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave) VALUES
      ('12tet', 'Twelve-tone equal temperament', 
       'Standard 12-tone equal temperament used in most modern music',
       ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
       440.0, 12);
  END IF;
END $$;