/*
  # Fix schema access and permissions

  1. Schema Setup
    - Reset and grant proper schema access
    - Enable RLS
    - Set up basic policies
  
  2. Security
    - Grant minimal required permissions
    - Set up basic tables
*/

-- Create extension if it doesn't exist
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create tables
CREATE TABLE IF NOT EXISTS public.temperaments (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  notes text[] NOT NULL,
  base_frequency float NOT NULL,
  divisions_per_octave integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.compositions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  temperament_id text REFERENCES public.temperaments NOT NULL,
  title text NOT NULL,
  chords jsonb NOT NULL,
  melody jsonb NOT NULL,
  tempo integer NOT NULL DEFAULT 120,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.temperaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compositions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public temperaments access"
  ON public.temperaments
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Users manage own compositions"
  ON public.compositions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Grant basic permissions
GRANT USAGE ON SCHEMA public TO PUBLIC;
GRANT ALL ON public.temperaments TO authenticated;
GRANT SELECT ON public.temperaments TO anon;
GRANT ALL ON public.compositions TO authenticated;

-- Insert default temperament
INSERT INTO public.temperaments (id, name, description, notes, base_frequency, divisions_per_octave)
VALUES (
  '12tet',
  'Twelve-tone equal temperament',
  'Standard 12-tone equal temperament used in most modern music',
  ARRAY['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
  440.0,
  12
) ON CONFLICT (id) DO NOTHING;